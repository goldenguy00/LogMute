# Log Mute

Mutes some logs that are constantly spammed but should be entirely ignored. Only targets UnityEngine and RoR2 logs.